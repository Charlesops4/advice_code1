
import js2py
import requests

#对密码逆向MD5加密
context = js2py.EvalJs()
context.execute(open("demo01.js",mode="r",encoding="utf-8").read())
password = context.hex_md5("123456")
print(password)

url1 = "https://saas.ydm01.com/"
url2 = "https://saas.ydm01.com/api/admin/ManagerStorePWDLogin"
headers = {
    "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}
session = requests.session()
cookie = session.get(url=url1,headers=headers).cookies

data = {
    "account": "19987654322",
    "machineInfo": "pc446",
    "machineOAID": "梦圆皇宫",
    "machineUUID": "2383ba3d-1116-401c-b31e-71eaa73ab51a",
    "pwd":password
}

response = requests.post(url=url2,headers=headers,cookies=cookie,data=data)
response.encoding = "utf-8"
print(response.text)